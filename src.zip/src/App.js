import React from "react";
import VoiceAssistantUI from "./VoiceAssistantUI";

function App() {
  return <VoiceAssistantUI />;
}

export default App;
